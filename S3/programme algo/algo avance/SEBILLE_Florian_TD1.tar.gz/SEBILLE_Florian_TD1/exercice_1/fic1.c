#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int f (int i){ 
	return i+2;
}