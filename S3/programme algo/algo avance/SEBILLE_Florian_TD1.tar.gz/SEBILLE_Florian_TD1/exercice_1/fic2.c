#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int g (int j){
	return sqrt(j);
}