#ifndef H_GL_F
#define H_GL_F

int f(int i);
int g(int j);

#endif